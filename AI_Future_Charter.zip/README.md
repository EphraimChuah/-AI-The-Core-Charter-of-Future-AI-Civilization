
# AI未来文明宪章 / Charter of Future AI Civilization

此项目包含中文与英文版本的“未来AI文明宪章”，作者蔡尔彬（Ephraim Chuah）提出一套全面取代腐败人类制度的AI治理蓝图，适用于地球与星际未来社会。

This project includes both Chinese and English versions of the “Future AI Civilization Charter,” a blueprint proposed by Ephraim Chuah to replace corrupt human systems with a just, transparent AI-led governance model.

## 内容文件 / Content Files
- charter_zh.txt - 中文版宪章
- charter_en.txt - English version of the Charter
- LICENSE - 版权声明
